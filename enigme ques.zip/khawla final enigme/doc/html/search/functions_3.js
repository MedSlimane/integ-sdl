var searchData=
[
  ['initenigme',['InitEnigme',['../enigmetf_8c.html#a569aeae3c3a1a439ea02d59e7761dc9e',1,'InitEnigme(enigmetf *e, char nomfichier[]):&#160;enigmetf.c'],['../enigmetf_8h.html#a569aeae3c3a1a439ea02d59e7761dc9e',1,'InitEnigme(enigmetf *e, char nomfichier[]):&#160;enigmetf.c']]]
];
