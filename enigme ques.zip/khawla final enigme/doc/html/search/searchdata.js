var indexSectionsWithContent =
{
  0: "abcdefimnpqrsv",
  1: "e",
  2: "em",
  3: "adfimv",
  4: "bcinpqrs"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables"
};

var indexSectionLabels =
{
  0: "Tout",
  1: "Structures de données",
  2: "Fichiers",
  3: "Fonctions",
  4: "Variables"
};

