var searchData=
[
  ['displayclock',['displayClock',['../enigmetf_8c.html#a987a7c0f199d3a0f59f8419c6d76741f',1,'displayClock(enigmetf e, SDL_Surface *ecran):&#160;enigmetf.c'],['../enigmetf_8h.html#a987a7c0f199d3a0f59f8419c6d76741f',1,'displayClock(enigmetf e, SDL_Surface *ecran):&#160;enigmetf.c']]]
];
